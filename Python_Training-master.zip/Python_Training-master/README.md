# Python_Training
Ten days python workshop at EXL Service by Abhaya Agrawal (Professional Trainer and Data Scientist)  

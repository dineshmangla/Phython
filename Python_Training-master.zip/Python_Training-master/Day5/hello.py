def world():
	print("hello world")

var='India'
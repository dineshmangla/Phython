class A_class():
	def fun(self):
		print("I am in fun")